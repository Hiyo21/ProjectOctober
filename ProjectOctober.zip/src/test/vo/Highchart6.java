package test.vo;

public class Highchart6 {
	private String timeHour;
	private int amountSum;
	
	public String getTimeHour() {
		return timeHour;
	}
	public void setTimeHour(String timeHour) {
		this.timeHour = timeHour;
	}
	public int getAmountSum() {
		return amountSum;
	}
	public void setAmountSum(int amountSum) {
		this.amountSum = amountSum;
	}
	@Override
	public String toString() {
		return "Highchart6 [timeHour=" + timeHour + ", amountSum=" + amountSum + "]";
	}
	
	
}
