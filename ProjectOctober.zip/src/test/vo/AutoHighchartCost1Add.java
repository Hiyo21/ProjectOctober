package test.vo;

public class AutoHighchartCost1Add {
	private String tai;
	private String gyung;
	private String kairo;
	private String bal;
	private String body;
	private String face;
	private String aroma;
	private String sleeming;
	private String wedding;
	
	private int taiCost;
	private int gyungCost;
	private int kairoCost;
	private int balCost;
	private int bodyCost;
	private int faceCost;
	private int aromaCost;
	private int sleemingCost;
	private int weddingCost;
	public String getTai() {
		return tai;
	}
	public void setTai(String tai) {
		this.tai = tai;
	}
	public String getGyung() {
		return gyung;
	}
	public void setGyung(String gyung) {
		this.gyung = gyung;
	}
	public String getKairo() {
		return kairo;
	}
	public void setKairo(String kairo) {
		this.kairo = kairo;
	}
	public String getBal() {
		return bal;
	}
	public void setBal(String bal) {
		this.bal = bal;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getFace() {
		return face;
	}
	public void setFace(String face) {
		this.face = face;
	}
	public String getAroma() {
		return aroma;
	}
	public void setAroma(String aroma) {
		this.aroma = aroma;
	}
	public String getSleeming() {
		return sleeming;
	}
	public void setSleeming(String sleeming) {
		this.sleeming = sleeming;
	}
	public String getWedding() {
		return wedding;
	}
	public void setWedding(String wedding) {
		this.wedding = wedding;
	}
	public int getTaiCost() {
		return taiCost;
	}
	public void setTaiCost(int taiCost) {
		this.taiCost = taiCost;
	}
	public int getGyungCost() {
		return gyungCost;
	}
	public void setGyungCost(int gyungCost) {
		this.gyungCost = gyungCost;
	}
	public int getKairoCost() {
		return kairoCost;
	}
	public void setKairoCost(int kairoCost) {
		this.kairoCost = kairoCost;
	}
	public int getBalCost() {
		return balCost;
	}
	public void setBalCost(int balCost) {
		this.balCost = balCost;
	}
	public int getBodyCost() {
		return bodyCost;
	}
	public void setBodyCost(int bodyCost) {
		this.bodyCost = bodyCost;
	}
	public int getFaceCost() {
		return faceCost;
	}
	public void setFaceCost(int faceCost) {
		this.faceCost = faceCost;
	}
	public int getAromaCost() {
		return aromaCost;
	}
	public void setAromaCost(int aromaCost) {
		this.aromaCost = aromaCost;
	}
	public int getSleemingCost() {
		return sleemingCost;
	}
	public void setSleemingCost(int sleemingCost) {
		this.sleemingCost = sleemingCost;
	}
	public int getWeddingCost() {
		return weddingCost;
	}
	public void setWeddingCost(int weddingCost) {
		this.weddingCost = weddingCost;
	}
	@Override
	public String toString() {
		return "AutoHighchartCost1Add [tai=" + tai + ", gyung=" + gyung + ", kairo=" + kairo + ", bal=" + bal
				+ ", body=" + body + ", face=" + face + ", aroma=" + aroma + ", sleeming=" + sleeming + ", wedding="
				+ wedding + ", taiCost=" + taiCost + ", gyungCost=" + gyungCost + ", kairoCost=" + kairoCost
				+ ", balCost=" + balCost + ", bodyCost=" + bodyCost + ", faceCost=" + faceCost + ", aromaCost="
				+ aromaCost + ", sleemingCost=" + sleemingCost + ", weddingCost=" + weddingCost + "]";
	}
	
	
}


