package test.vo;

public class Highchart9 {
	private String time;
	private int total;
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Highchart9 [time=" + time + ", total=" + total + "]";
	}

}


