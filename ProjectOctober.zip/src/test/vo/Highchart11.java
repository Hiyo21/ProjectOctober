package test.vo;

public class Highchart11 {
	private String job;
	private int total;
	private int jubu;
	private int free;
	private int other;
	private int company;
	private int student;
	private int expert;
	
	
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getJubu() {
		return jubu;
	}
	public void setJubu(int jubu) {
		this.jubu = jubu;
	}
	public int getFree() {
		return free;
	}
	public void setFree(int free) {
		this.free = free;
	}
	public int getOther() {
		return other;
	}
	public void setOther(int other) {
		this.other = other;
	}
	public int getCompany() {
		return company;
	}
	public void setCompany(int company) {
		this.company = company;
	}
	public int getStudent() {
		return student;
	}
	public void setStudent(int student) {
		this.student = student;
	}
	public int getExpert() {
		return expert;
	}
	public void setExpert(int expert) {
		this.expert = expert;
	}
	@Override
	public String toString() {
		return "Highchart11 [job=" + job + ", total=" + total + ", jubu=" + jubu + ", free=" + free + ", other=" + other
				+ ", company=" + company + ", student=" + student + ", expert=" + expert + "]";
	}
	
	
}

