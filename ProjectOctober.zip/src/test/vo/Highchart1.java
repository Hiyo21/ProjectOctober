package test.vo;

public class Highchart1 {
	private int age;
	private int countGender;
	private String cGender;
	private String rsvGender;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getCountGender() {
		return countGender;
	}
	public void setCountGender(int countGender) {
		this.countGender = countGender;
	}
	public String getcGender() {
		return cGender;
	}
	public void setcGender(String cGender) {
		this.cGender = cGender;
	}
	public String getRsvGender() {
		return rsvGender;
	}
	public void setRsvGender(String rsvGender) {
		this.rsvGender = rsvGender;
	}
	@Override
	public String toString() {
		return "Highchart1 [age=" + age + ", countGender=" + countGender + ", cGender=" + cGender + ", rsvGender="
				+ rsvGender + "]";
	}
	
	
	
}
