package test.vo;

public class Highchart12 {
	private String service;
	private int total;
	
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Highchart12 [service=" + service + ", total=" + total + "]";
	}
}
