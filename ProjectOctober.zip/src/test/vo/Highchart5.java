package test.vo;

public class Highchart5 {
	private String dayby;
	private int rs;
	
	public String getDayby() {
		return dayby;
	}
	public void setDayby(String dayby) {
		this.dayby = dayby;
	}
	public int getRs() {
		return rs;
	}
	public void setRs(int rs) {
		this.rs = rs;
	}
	@Override
	public String toString() {
		return "Highchart5 [dayby=" + dayby + ", rs=" + rs + "]";
	}
	
}

