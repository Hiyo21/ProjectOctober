package test.vo;

public class Highchart2 {
	private int age;
	private int hygiene;
	private int comfort;
	private int technique;
	private int price;
	private int service;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getHygiene() {
		return hygiene;
	}
	public void setHygiene(int hygiene) {
		this.hygiene = hygiene;
	}
	public int getComfort() {
		return comfort;
	}
	public void setComfort(int comfort) {
		this.comfort = comfort;
	}
	public int getTechnique() {
		return technique;
	}
	public void setTechnique(int technique) {
		this.technique = technique;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getService() {
		return service;
	}
	public void setService(int service) {
		this.service = service;
	}
	@Override
	public String toString() {
		return "Highchart2 [age=" + age + ", hygiene=" + hygiene + ", comfort=" + comfort + ", technique=" + technique
				+ ", price=" + price + ", service=" + service + "]";
	}
	
	
}
