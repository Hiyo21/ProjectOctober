package test.vo;

public class Highchart11Cost {
	private int age;
	private int customerNum;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}
	@Override
	public String toString() {
		return "Highchart11 [age=" + age + ", customerNum=" + customerNum + "]";
	}
	
	
	
}



