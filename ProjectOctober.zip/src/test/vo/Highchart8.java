package test.vo;

public class Highchart8 {
	private int amountSum;

	public int getAmountSum() {
		return amountSum;
	}

	public void setAmountSum(int amountSum) {
		this.amountSum = amountSum;
	}

	@Override
	public String toString() {
		return "Highchart8 [amountSum=" + amountSum + "]";
	}

	
}
