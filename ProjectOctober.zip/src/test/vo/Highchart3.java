package test.vo;

public class Highchart3 {
	private String wea;
	private int cnt;
	private String title;
	
	public String getWea() {
		return wea;
	}
	public void setWea(String wea) {
		this.wea = wea;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "Highchart3 [wea=" + wea + ", cnt=" + cnt + ", title=" + title + "]";
	}
	
}


