package test.vo;

public class AutoHighchartCost3 {
	private String age;
	private int customerNum;
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public int getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}
	@Override
	public String toString() {
		return "AutoHighchartCost3 [age=" + age + ", customerNum=" + customerNum + "]";
	}
	
}



	