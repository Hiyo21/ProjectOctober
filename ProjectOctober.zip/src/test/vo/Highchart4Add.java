package test.vo;

public class Highchart4Add {
	private int jubu1;
	private int free1;
	private int other1;
	private int company1;
	private int student1;
	private int expert1;
	public int getJubu1() {
		return jubu1;
	}
	public void setJubu1(int jubu1) {
		this.jubu1 = jubu1;
	}
	public int getFree1() {
		return free1;
	}
	public void setFree1(int free1) {
		this.free1 = free1;
	}
	public int getOther1() {
		return other1;
	}
	public void setOther1(int other1) {
		this.other1 = other1;
	}
	public int getCompany1() {
		return company1;
	}
	public void setCompany1(int company1) {
		this.company1 = company1;
	}
	public int getStudent1() {
		return student1;
	}
	public void setStudent1(int student1) {
		this.student1 = student1;
	}
	public int getExpert1() {
		return expert1;
	}
	public void setExpert1(int expert1) {
		this.expert1 = expert1;
	}
	@Override
	public String toString() {
		return "Highchart4Add [jubu1=" + jubu1 + ", free1=" + free1 + ", other1=" + other1 + ", company1=" + company1
				+ ", student1=" + student1 + ", expert1=" + expert1 + "]";
	}
}
