package test.vo;

public class Highchart9AddCost {
	private int sale1;
	private int sale2;
	private int sale3;
	private int sale4;
	private int sale5;
	private int sale6;
	private int sale7;
	private int sale8;
	private int sale9;
	private int sale10;
	public int getSale1() {
		return sale1;
	}
	public void setSale1(int sale1) {
		this.sale1 = sale1;
	}
	public int getSale2() {
		return sale2;
	}
	public void setSale2(int sale2) {
		this.sale2 = sale2;
	}
	public int getSale3() {
		return sale3;
	}
	public void setSale3(int sale3) {
		this.sale3 = sale3;
	}
	public int getSale4() {
		return sale4;
	}
	public void setSale4(int sale4) {
		this.sale4 = sale4;
	}
	public int getSale5() {
		return sale5;
	}
	public void setSale5(int sale5) {
		this.sale5 = sale5;
	}
	public int getSale6() {
		return sale6;
	}
	public void setSale6(int sale6) {
		this.sale6 = sale6;
	}
	public int getSale7() {
		return sale7;
	}
	public void setSale7(int sale7) {
		this.sale7 = sale7;
	}
	public int getSale8() {
		return sale8;
	}
	public void setSale8(int sale8) {
		this.sale8 = sale8;
	}
	public int getSale9() {
		return sale9;
	}
	public void setSale9(int sale9) {
		this.sale9 = sale9;
	}
	public int getSale10() {
		return sale10;
	}
	public void setSale10(int sale10) {
		this.sale10 = sale10;
	}
	@Override
	public String toString() {
		return "Highchart9Add [sale1=" + sale1 + ", sale2=" + sale2 + ", sale3=" + sale3 + ", sale4=" + sale4
				+ ", sale5=" + sale5 + ", sale6=" + sale6 + ", sale7=" + sale7 + ", sale8=" + sale8 + ", sale9=" + sale9
				+ ", sale10=" + sale10 + "]";
	}
	
	
}
