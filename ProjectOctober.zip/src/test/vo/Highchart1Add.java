package test.vo;

public class Highchart1Add {
	private int first;
	private int second;
	private int third;
	private int forth;
	private int fifth;
	
	public int getFirst() {
		return first;
	}
	public void setFirst(int first) {
		this.first = first;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		this.second = second;
	}
	public int getThird() {
		return third;
	}
	public void setThird(int third) {
		this.third = third;
	}
	public int getForth() {
		return forth;
	}
	public void setForth(int forth) {
		this.forth = forth;
	}
	public int getFifth() {
		return fifth;
	}
	public void setFifth(int fifth) {
		this.fifth = fifth;
	}
	@Override
	public String toString() {
		return "Highchart1Add [first=" + first + ", second=" + second + ", third=" + third + ", forth=" + forth
				+ ", fifth=" + fifth + "]";
	}
	
	
	
}
