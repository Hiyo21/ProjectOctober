package test.vo;

public class Highchart3Add {
	private int spring;
	private int summer;
	private int fall;
	private int winter;
	
	public int getSpring() {
		return spring;
	}
	public void setSpring(int spring) {
		this.spring = spring;
	}
	public int getSummer() {
		return summer;
	}
	public void setSummer(int summer) {
		this.summer = summer;
	}
	public int getFall() {
		return fall;
	}
	public void setFall(int fall) {
		this.fall = fall;
	}
	public int getWinter() {
		return winter;
	}
	public void setWinter(int winter) {
		this.winter = winter;
	}
	@Override
	public String toString() {
		return "Highchart3Add [spring=" + spring + ", summer=" + summer + ", fall=" + fall + ", winter=" + winter + "]";
	}	
	
}
