package test.vo;

public class Highchart10 {
	private int avgAmount;
	private String MonthA;
	
	public int getAvgAmount() {
		return avgAmount;
	}
	public void setAvgAmount(int avgAmount) {
		this.avgAmount = avgAmount;
	}
	public String getMonthA() {
		return MonthA;
	}
	public void setMonthA(String monthA) {
		MonthA = monthA;
	}
	@Override
	public String toString() {
		return "Highchart10 [avgAmount=" + avgAmount + ", MonthA=" + MonthA + "]";
	}
	
	
	
}

