package test.vo;

public class Highchart4 {
	private String cstJob;
	private int moneyflow;

	public String getCstJob() {
		return cstJob;
	}
	public void setCstJob(String cstJob) {
		this.cstJob = cstJob;
	}
	public int getMoneyflow() {
		return moneyflow;
	}
	public void setMoneyflow(int moneyflow) {
		this.moneyflow = moneyflow;
	}
	@Override
	public String toString() {

		return "Highchart4 [cstJob=" + cstJob + ", moneyflow=" + moneyflow
				+ "]";

	}
	
	
	
	
}


