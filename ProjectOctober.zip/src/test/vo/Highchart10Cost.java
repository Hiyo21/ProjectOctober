package test.vo;

public class Highchart10Cost {
	private String etpNum;
	private String timeSet;
	private int countNum;
	
	public String getEtpNum() {
		return etpNum;
	}
	public void setEtpNum(String etpNum) {
		this.etpNum = etpNum;
	}
	public String getTimeSet() {
		return timeSet;
	}
	public void setTimeSet(String timeSet) {
		this.timeSet = timeSet;
	}
	public int getCountNum() {
		return countNum;
	}
	public void setCountNum(int countNum) {
		this.countNum = countNum;
	}
	@Override
	public String toString() {
		return "Highchart10 [etpNum=" + etpNum + ", timeSet=" + timeSet + ", countNum=" + countNum + "]";
	}
	
	
	
	
}
