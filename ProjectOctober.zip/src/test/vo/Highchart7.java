package test.vo;

public class Highchart7 {
	private String yeardate;
	private String quater;
	private int hygiene;
	private int comfort;
	private int technique;
	private int price;
	private int service;
	public String getYeardate() {
		return yeardate;
	}
	public void setYeardate(String yeardate) {
		this.yeardate = yeardate;
	}
	public String getQuater() {
		return quater;
	}
	public void setQuater(String quater) {
		this.quater = quater;
	}
	public int getHygiene() {
		return hygiene;
	}
	public void setHygiene(int hygiene) {
		this.hygiene = hygiene;
	}
	public int getComfort() {
		return comfort;
	}
	public void setComfort(int comfort) {
		this.comfort = comfort;
	}
	public int getTechnique() {
		return technique;
	}
	public void setTechnique(int technique) {
		this.technique = technique;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getService() {
		return service;
	}
	public void setService(int service) {
		this.service = service;
	}
	@Override
	public String toString() {
		return "Highchart7 [yeardate=" + yeardate + ", quater=" + quater + ", hygiene=" + hygiene + ", comfort="
				+ comfort + ", technique=" + technique + ", price=" + price + ", service=" + service + "]";
	}
	
	
	
	
}
