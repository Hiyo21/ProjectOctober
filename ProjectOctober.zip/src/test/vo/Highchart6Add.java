package test.vo;

public class Highchart6Add {
	private int time0;
	private int time1;
	private int time2;
	private int time3;
	private int time4;
	private int time5;
	private int time6;
	private int time7;
	private int time8;
	private int time9;
	private int time10;
	private int time11;
	private int time12;
	private int time13;
	private int time14;
	private int time15;
	private int time16;
	private int time17;
	private int time18;
	private int time19;
	private int time20;
	private int time21;
	private int time22;
	private int time23;
	private int time24;
	public int getTime0() {
		return time0;
	}
	public void setTime0(int time0) {
		this.time0 = time0;
	}
	public int getTime1() {
		return time1;
	}
	public void setTime1(int time1) {
		this.time1 = time1;
	}
	public int getTime2() {
		return time2;
	}
	public void setTime2(int time2) {
		this.time2 = time2;
	}
	public int getTime3() {
		return time3;
	}
	public void setTime3(int time3) {
		this.time3 = time3;
	}
	public int getTime4() {
		return time4;
	}
	public void setTime4(int time4) {
		this.time4 = time4;
	}
	public int getTime5() {
		return time5;
	}
	public void setTime5(int time5) {
		this.time5 = time5;
	}
	public int getTime6() {
		return time6;
	}
	public void setTime6(int time6) {
		this.time6 = time6;
	}
	public int getTime7() {
		return time7;
	}
	public void setTime7(int time7) {
		this.time7 = time7;
	}
	public int getTime8() {
		return time8;
	}
	public void setTime8(int time8) {
		this.time8 = time8;
	}
	public int getTime9() {
		return time9;
	}
	public void setTime9(int time9) {
		this.time9 = time9;
	}
	public int getTime10() {
		return time10;
	}
	public void setTime10(int time10) {
		this.time10 = time10;
	}
	public int getTime11() {
		return time11;
	}
	public void setTime11(int time11) {
		this.time11 = time11;
	}
	public int getTime12() {
		return time12;
	}
	public void setTime12(int time12) {
		this.time12 = time12;
	}
	public int getTime13() {
		return time13;
	}
	public void setTime13(int time13) {
		this.time13 = time13;
	}
	public int getTime14() {
		return time14;
	}
	public void setTime14(int time14) {
		this.time14 = time14;
	}
	public int getTime15() {
		return time15;
	}
	public void setTime15(int time15) {
		this.time15 = time15;
	}
	public int getTime16() {
		return time16;
	}
	public void setTime16(int time16) {
		this.time16 = time16;
	}
	public int getTime17() {
		return time17;
	}
	public void setTime17(int time17) {
		this.time17 = time17;
	}
	public int getTime18() {
		return time18;
	}
	public void setTime18(int time18) {
		this.time18 = time18;
	}
	public int getTime19() {
		return time19;
	}
	public void setTime19(int time19) {
		this.time19 = time19;
	}
	public int getTime20() {
		return time20;
	}
	public void setTime20(int time20) {
		this.time20 = time20;
	}
	public int getTime21() {
		return time21;
	}
	public void setTime21(int time21) {
		this.time21 = time21;
	}
	public int getTime22() {
		return time22;
	}
	public void setTime22(int time22) {
		this.time22 = time22;
	}
	public int getTime23() {
		return time23;
	}
	public void setTime23(int time23) {
		this.time23 = time23;
	}
	public int getTime24() {
		return time24;
	}
	public void setTime24(int time24) {
		this.time24 = time24;
	}
	@Override
	public String toString() {
		return "Highchart6Add [time0=" + time0 + ", time1=" + time1 + ", time2=" + time2 + ", time3=" + time3
				+ ", time4=" + time4 + ", time5=" + time5 + ", time6=" + time6 + ", time7=" + time7 + ", time8=" + time8
				+ ", time9=" + time9 + ", time10=" + time10 + ", time11=" + time11 + ", time12=" + time12 + ", time13="
				+ time13 + ", time14=" + time14 + ", time15=" + time15 + ", time16=" + time16 + ", time17=" + time17
				+ ", time18=" + time18 + ", time19=" + time19 + ", time20=" + time20 + ", time21=" + time21
				+ ", time22=" + time22 + ", time23=" + time23 + ", time24=" + time24 + "]";
	}
	
	
}
