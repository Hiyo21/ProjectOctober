package test.vo;

public class Highchart9Cost {
	private int rank;
	private int sale;
	
	
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public int getSale() {
		return sale;
	}
	public void setSale(int sale) {
		this.sale = sale;
	}
	@Override
	public String toString() {
		return "Highchart9 [rank=" + rank + ", sale=" + sale + "]";
	}
	
	
}
