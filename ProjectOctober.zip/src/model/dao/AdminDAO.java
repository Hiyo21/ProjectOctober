package model.dao;

public class AdminDAO {

}
