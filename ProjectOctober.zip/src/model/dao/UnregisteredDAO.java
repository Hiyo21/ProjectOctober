package model.dao;

public class UnregisteredDAO {

}
